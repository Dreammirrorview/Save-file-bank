/* ============================================
   GLOBAL PILGRIM BANK PLC - APPLICATION LOGIC
   "Hope Like We Make Future"
   ============================================ */

// ============ DATA STORE ============
const DB = {
  admin: {
    id: 'GPB-ADMIN-001',
    password: 'Pilgrim@2024',
    name: 'Olawale Abdul-Ganiyu Adeshina',
    accountNumber: 'GPB-0000000001',
    balance: { USD: 1000000, EUR: 850000, GBP: 750000, NGN: 500000000, BTC: 5.5, ETH: 25, USDT: 50000, PILGRIM: 100000 },
    tradingProfit: 0,
    miningProfit: 0
  },
  customers: [],
  transactions: [],
  departments: [],
  invoices: [],
  rechargeCards: [],
  mining: {},
  exchangeRates: {
    'USD/NGN': 1580.50, 'USD/EUR': 0.92, 'USD/GBP': 0.79, 'USD/BTC': 0.0000148,
    'USD/ETH': 0.000303, 'USD/USDT': 1.0, 'USD/PILGRIM': 1.0,
    'EUR/NGN': 1717.93, 'GBP/NGN': 2000.63, 'BTC/USD': 67500, 'ETH/USD': 3300,
    'NGN/USD': 0.000633, 'EUR/USD': 1.087, 'GBP/USD': 1.266
  },
  tradingState: { robotActive: false, profit: 0, trades: 0, wins: 0, interval: null },
  custTradingState: { robotActive: false, profit: 0, interval: null },
  currentCustomer: null
};

// ============ CRYPTO CONFIG ============
const CRYPTO_LIST = [
  { id: 'BTC', name: 'Bitcoin', icon: '₿', color: '#f7931a' },
  { id: 'ETH', name: 'Ethereum', icon: 'Ξ', color: '#627eea' },
  { id: 'USDT', name: 'Tether', icon: '₮', color: '#26a17b' },
  { id: 'BNB', name: 'BNB', icon: '◆', color: '#f3ba2f' },
  { id: 'SOL', name: 'Solana', icon: '◎', color: '#9945ff' },
  { id: 'XRP', name: 'Ripple', icon: '✕', color: '#00aae4' },
  { id: 'ADA', name: 'Cardano', icon: '₳', color: '#0033ad' },
  { id: 'DOGE', name: 'Dogecoin', icon: 'Ð', color: '#c2a633' },
  { id: 'TRX', name: 'TRON', icon: '⟁', color: '#ff0013' },
  { id: 'TON', name: 'TON', icon: '⊕', color: '#0098ea' },
  { id: 'MATIC', name: 'Polygon', icon: '⬡', color: '#8247e5' },
  { id: 'DOT', name: 'Polkadot', icon: '●', color: '#e6007a' },
  { id: 'AVAX', name: 'Avalanche', icon: '▲', color: '#e84142' },
  { id: 'LINK', name: 'Chainlink', icon: '⬡', color: '#2a5ada' },
  { id: 'LTC', name: 'Litecoin', icon: 'Ł', color: '#bfbbbb' },
  { id: 'PILGRIM', name: 'Pilgrim Coin', icon: '☦', color: '#d4af37' }
];

const CURRENCY_LIST = [
  { id: 'USD', name: 'US Dollar', symbol: '$' },
  { id: 'EUR', name: 'Euro', symbol: '€' },
  { id: 'GBP', name: 'British Pound', symbol: '£' },
  { id: 'NGN', name: 'Nigerian Naira', symbol: '₦' },
  { id: 'CNY', name: 'Chinese Yuan', symbol: '¥' },
  { id: 'JPY', name: 'Japanese Yen', symbol: '¥' },
  { id: 'CAD', name: 'Canadian Dollar', symbol: 'C$' },
  { id: 'AUD', name: 'Australian Dollar', symbol: 'A$' },
  { id: 'CHF', name: 'Swiss Franc', symbol: 'CHF' },
  { id: 'INR', name: 'Indian Rupee', symbol: '₹' },
  { id: 'ZAR', name: 'South African Rand', symbol: 'R' },
  { id: 'GHS', name: 'Ghanaian Cedi', symbol: '₵' },
  { id: 'KES', name: 'Kenyan Shilling', symbol: 'KSh' },
  { id: 'AED', name: 'UAE Dirham', symbol: 'د.إ' },
  { id: 'BRL', name: 'Brazilian Real', symbol: 'R$' }
];

// ============ UTILITY FUNCTIONS ============
function generateAccountNumber() {
  const prefix = 'GPB-';
  let num = '';
  for (let i = 0; i < 10; i++) num += Math.floor(Math.random() * 10);
  return prefix + num;
}

function generateTxId() {
  const prefix = 'TX-';
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let id = prefix;
  for (let i = 0; i < 12; i++) id += chars.charAt(Math.floor(Math.random() * chars.length));
  return id;
}

function generateWalletAddress(prefix) {
  const chars = '0123456789abcdef';
  let addr = prefix || '0x';
  for (let i = 0; i < 40; i++) addr += chars.charAt(Math.floor(Math.random() * chars.length));
  return addr;
}

function generatePassword(length = 12) {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%&*';
  let pass = '';
  for (let i = 0; i < length; i++) pass += chars.charAt(Math.floor(Math.random() * chars.length));
  return pass;
}

function generateRechargePin() {
  let pin = '';
  for (let i = 0; i < 4; i++) {
    if (i > 0) pin += '-';
    for (let j = 0; j < 4; j++) pin += Math.floor(Math.random() * 10);
  }
  return pin;
}

function formatCurrency(amount, currency) {
  const symbols = { USD: '$', EUR: '€', GBP: '£', NGN: '₦', BTC: '₿', ETH: 'Ξ', USDT: '₮', PILGRIM: '☦', CNY: '¥', JPY: '¥', CAD: 'C$', AUD: 'A$', CHF: 'CHF', INR: '₹', ZAR: 'R', GHS: '₵', KES: 'KSh', AED: 'د.إ', BRL: 'R$' };
  const sym = symbols[currency] || currency + ' ';
  if (currency === 'BTC' || currency === 'ETH') return sym + parseFloat(amount).toFixed(8);
  return sym + parseFloat(amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function getDateTime() {
  const now = new Date();
  return now.toLocaleString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function notify(message, type = 'info') {
  const bar = document.getElementById('notificationBar');
  const notif = document.createElement('div');
  notif.className = 'notification ' + type;
  const icons = { success: 'check-circle', error: 'exclamation-circle', warning: 'exclamation-triangle', info: 'info-circle' };
  notif.innerHTML = '<i class="fas fa-' + icons[type] + '"></i> ' + message;
  bar.appendChild(notif);
  setTimeout(() => notif.remove(), 5000);
}

// ============ PAGE NAVIGATION ============
function showPage(pageId) {
  const pages = ['adminLoginPage', 'customerLoginPage', 'signupPage', 'adminDashboard', 'customerDashboard'];
  pages.forEach(p => document.getElementById(p).style.display = 'none');
  document.getElementById(pageId).style.display = pageId.includes('Dashboard') ? 'flex' : 'flex';
  // Reset display for auth pages
  if (pageId.includes('Login') || pageId === 'signupPage') {
    document.getElementById(pageId).style.display = 'flex';
  }
}

function showAdminPage(pageId) {
  document.querySelectorAll('#adminDashboard .page').forEach(p => p.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  document.querySelectorAll('#adminSidebar .nav-item').forEach(n => n.classList.remove('active'));
  if (typeof event !== 'undefined' && event && event.target) {
    event.target.closest('.nav-item')?.classList.add('active');
  }
  // Refresh data on page show
  if (pageId === 'adminMining') renderMiningCards();
  if (pageId === 'adminTrading') renderTradingChart();
  if (pageId === 'adminWallets') renderAdminWallets();
  if (pageId === 'adminRates') renderDetailedRates();
  if (pageId === 'adminCustomers') renderCustomersTable();
  if (pageId === 'adminPayroll') renderPayroll();
  if (pageId === 'adminInvoices') renderInvoices();
  if (pageId === 'adminOverview') refreshAdminOverview();
  if (pageId === 'adminTransactions') populateSenderAccounts();
}

function showCustPage(pageId) {
  document.querySelectorAll('#customerDashboard .page').forEach(p => p.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  document.querySelectorAll('#customerSidebar .nav-item').forEach(n => n.classList.remove('active'));
  if (typeof event !== 'undefined' && event && event.target) {
    event.target.closest('.nav-item')?.classList.add('active');
  }
  if (pageId === 'custMining') renderCustMiningCards();
  if (pageId === 'custTrading') renderCustTradingChart();
  if (pageId === 'custWallets') renderCustWallets();
  if (pageId === 'custOverview') refreshCustOverview();
  if (pageId === 'custTransactions') populateCustReceiveDetails();
}

function toggleSidebar(id) {
  document.getElementById(id).classList.toggle('mobile-open');
}

function switchTab(btn, group, tabId) {
  document.querySelectorAll(`.tab-btn`).forEach(b => {
    if (b.parentElement === btn.parentElement) b.classList.remove('active');
  });
  btn.classList.add('active');
  document.querySelectorAll(`.tab-content[data-group="${group}"]`).forEach(t => t.classList.remove('active'));
  document.getElementById(tabId).classList.add('active');
}

function showModal(id) { document.getElementById(id).classList.add('active'); }
function hideModal(id) { document.getElementById(id).classList.remove('active'); }

// ============ AUTH: ADMIN LOGIN ============
function adminLogin() {
  const id = document.getElementById('adminLoginId').value;
  const pass = document.getElementById('adminLoginPass').value;
  if (id === DB.admin.id && pass === DB.admin.password) {
    showPage('adminDashboard');
    initAdminDashboard();
    notify('Welcome, Administrator!', 'success');
  } else {
    notify('Invalid admin credentials', 'error');
  }
}

function adminLogout() {
  stopRobotTrading();
  showPage('adminLoginPage');
  notify('Logged out successfully', 'info');
}

// ============ AUTH: CUSTOMER LOGIN ============
function customerLogin() {
  const acct = document.getElementById('custLoginAcct').value.trim();
  const pass = document.getElementById('custLoginPass').value;
  const cust = DB.customers.find(c => (c.accountNumber === acct || c.email === acct) && c.password === pass);
  if (cust) {
    if (cust.status !== 'active') {
      notify('Account is ' + cust.status + '. Contact admin.', 'error');
      return;
    }
    DB.currentCustomer = cust;
    showPage('customerDashboard');
    initCustomerDashboard();
    notify('Welcome, ' + cust.firstName + '!', 'success');
  } else {
    notify('Invalid account number/email or password', 'error');
  }
}

function customerLogout() {
  custStopRobot();
  DB.currentCustomer = null;
  showPage('customerLoginPage');
  notify('Logged out successfully', 'info');
}

// ============ AUTH: CUSTOMER SIGNUP ============
function customerSignup() {
  const firstName = document.getElementById('signupFirstName').value.trim();
  const lastName = document.getElementById('signupLastName').value.trim();
  const dob = document.getElementById('signupDob').value;
  const country = document.getElementById('signupCountry').value;
  const phone = document.getElementById('signupPhone').value.trim();
  const email = document.getElementById('signupEmail').value.trim();
  const acctType = document.getElementById('signupAcctType').value;
  const address = document.getElementById('signupAddress').value.trim();
  const bvn = document.getElementById('signupBvn').value.trim();
  const password = document.getElementById('signupPassword').value;
  const confirm = document.getElementById('signupConfirm').value;

  if (!firstName || !lastName || !email || !password) {
    notify('Please fill in all required fields', 'error');
    return;
  }
  if (password !== confirm) {
    notify('Passwords do not match', 'error');
    return;
  }
  if (password.length < 6) {
    notify('Password must be at least 6 characters', 'error');
    return;
  }
  if (DB.customers.find(c => c.email === email)) {
    notify('Email already registered', 'error');
    return;
  }

  const accountNumber = generateAccountNumber();
  const customer = {
    accountNumber,
    firstName, lastName, dob, country, phone, email, address, bvn,
    accountType: acctType,
    password,
    status: 'active',
    balances: { USD: 0, EUR: 0, GBP: 0, NGN: 0, BTC: 0, ETH: 0, USDT: 0, PILGRIM: 0 },
    walletAddresses: {},
    createdAt: new Date().toISOString(),
    transactions: []
  };

  // Generate wallet addresses
  CRYPTO_LIST.forEach(c => {
    const prefixes = { BTC: '1', ETH: '0x', USDT: 'T', BNB: 'bnb1', SOL: 'So1', PILGRIM: 'P' };
    customer.walletAddresses[c.id] = generateWalletAddress(prefixes[c.id] || '0x');
  });

  DB.customers.push(customer);
  addTransaction(customer.accountNumber, 'credit', 'Account Opening Bonus', 0, 'USD', 'completed');

  notify('Account created! Your account number is: ' + accountNumber, 'success');
  notify('Your password: ' + password, 'info');
  document.getElementById('custLoginAcct').value = accountNumber;
  showPage('customerLoginPage');
}

// ============ ADMIN DASHBOARD INIT ============
function initAdminDashboard() {
  updateClocks();
  updateTicker();
  refreshAdminOverview();
  renderCustomersTable();
  renderPayroll();
  renderInvoices();
  renderMiningCards();
  renderAdminWallets();
  populateSenderAccounts();
  document.getElementById('receiveAcctNum').value = DB.admin.accountNumber;
}

function refreshAdminOverview() {
  document.getElementById('totalCustomers').textContent = DB.customers.length;
  const totalBal = DB.customers.reduce((s, c) => s + (c.balances.USD || 0), 0) + DB.admin.balance.USD;
  document.getElementById('totalBalances').textContent = formatCurrency(totalBal, 'USD');
  document.getElementById('totalTransactions').textContent = DB.transactions.length;
  let totalMined = 0;
  Object.values(DB.mining).forEach(m => { if (m.active) totalMined += m.mined; });
  document.getElementById('miningRewards').textContent = totalMined.toFixed(8);

  // Recent activity
  const activity = document.getElementById('adminRecentActivity');
  const recent = DB.transactions.slice(-5).reverse();
  if (recent.length) {
    activity.innerHTML = recent.map(t => `
      <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid rgba(26,58,92,0.5)">
        <div>
          <div style="font-size:13px">${t.description}</div>
          <div style="font-size:11px;color:var(--text-muted)">${t.date}</div>
        </div>
        <div style="font-size:13px;color:${t.type === 'credit' ? 'var(--success)' : 'var(--danger)'}">
          ${t.type === 'credit' ? '+' : '-'}${formatCurrency(t.amount, t.currency)}
        </div>
      </div>
    `).join('');
  }

  renderExchangeRates();
}

// ============ CUSTOMER MANAGEMENT ============
function createCustomer() {
  const firstName = document.getElementById('newCustFirst').value.trim();
  const lastName = document.getElementById('newCustLast').value.trim();
  const email = document.getElementById('newCustEmail').value.trim();
  const phone = document.getElementById('newCustPhone').value.trim();
  const country = document.getElementById('newCustCountry').value.trim();
  const address = document.getElementById('newCustAddress').value.trim();
  const acctType = document.getElementById('newCustType').value;
  const deposit = parseFloat(document.getElementById('newCustDeposit').value) || 0;
  let password = document.getElementById('newCustPassword').value.trim();
  if (!password) password = generatePassword();

  if (!firstName || !lastName || !email) {
    notify('First name, last name and email are required', 'error');
    return;
  }

  const accountNumber = generateAccountNumber();
  const customer = {
    accountNumber, firstName, lastName, email, phone, country, address,
    accountType: acctType, password, status: 'active',
    balances: { USD: deposit, EUR: 0, GBP: 0, NGN: 0, BTC: 0, ETH: 0, USDT: 0, PILGRIM: 0 },
    walletAddresses: {},
    createdAt: new Date().toISOString(),
    transactions: []
  };

  CRYPTO_LIST.forEach(c => {
    const prefixes = { BTC: '1', ETH: '0x', USDT: 'T', BNB: 'bnb1', SOL: 'So1', PILGRIM: 'P' };
    customer.walletAddresses[c.id] = generateWalletAddress(prefixes[c.id] || '0x');
  });

  DB.customers.push(customer);
  if (deposit > 0) addTransaction(customer.accountNumber, 'credit', 'Initial Deposit', deposit, 'USD', 'completed');

  hideModal('createCustomerModal');
  renderCustomersTable();
  refreshAdminOverview();
  notify('Customer created! Account: ' + accountNumber + ' | Password: ' + password, 'success');
}

function renderCustomersTable() {
  const tbody = document.getElementById('customersTableBody');
  if (!tbody) return;
  if (DB.customers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:30px">No customers yet. Create one to get started.</td></tr>';
    return;
  }
  tbody.innerHTML = DB.customers.map((c, i) => `
    <tr>
      <td><span style="font-family:monospace;font-size:12px">${c.accountNumber}</span></td>
      <td>${c.firstName} ${c.lastName}</td>
      <td>${c.email}</td>
      <td>${c.phone || '—'}</td>
      <td>${formatCurrency(c.balances.USD, 'USD')}</td>
      <td><span class="badge badge-${c.status === 'active' ? 'success' : c.status === 'suspended' ? 'danger' : c.status === 'frozen' ? 'warning' : 'info'}">${c.status}</span></td>
      <td>
        <button class="btn btn-xs btn-info" onclick="editCustomer(${i})" title="Edit"><i class="fas fa-edit"></i></button>
        <button class="btn btn-xs btn-success" onclick="creditCustomer(${i})" title="Credit"><i class="fas fa-plus"></i></button>
        <button class="btn btn-xs btn-danger" onclick="debitCustomer(${i})" title="Debit"><i class="fas fa-minus"></i></button>
        <button class="btn btn-xs btn-warning" onclick="toggleCustStatus(${i})" title="Toggle Status"><i class="fas fa-ban"></i></button>
        <button class="btn btn-xs btn-secondary" onclick="resetCustPassword(${i})" title="Reset Password"><i class="fas fa-key"></i></button>
      </td>
    </tr>
  `).join('');
}

function editCustomer(idx) {
  const c = DB.customers[idx];
  document.getElementById('editCustIdx').value = idx;
  document.getElementById('editCustFirst').value = c.firstName;
  document.getElementById('editCustLast').value = c.lastName;
  document.getElementById('editCustEmail').value = c.email;
  document.getElementById('editCustPhone').value = c.phone || '';
  document.getElementById('editCustCountry').value = c.country || '';
  document.getElementById('editCustAddress').value = c.address || '';
  document.getElementById('editCustAcct').value = c.accountNumber;
  document.getElementById('editCustUsd').value = c.balances.USD;
  document.getElementById('editCustEur').value = c.balances.EUR;
  document.getElementById('editCustGbp').value = c.balances.GBP;
  document.getElementById('editCustNgn').value = c.balances.NGN;
  document.getElementById('editCustBtc').value = c.balances.BTC;
  document.getElementById('editCustEth').value = c.balances.ETH;
  document.getElementById('editCustUsdt').value = c.balances.USDT;
  document.getElementById('editCustPilgrim').value = c.balances.PILGRIM;
  document.getElementById('editCustStatus').value = c.status;
  document.getElementById('editCustNewPass').value = '';
  showModal('editCustomerModal');
}

function saveCustomerEdit() {
  const idx = parseInt(document.getElementById('editCustIdx').value);
  const c = DB.customers[idx];
  c.firstName = document.getElementById('editCustFirst').value;
  c.lastName = document.getElementById('editCustLast').value;
  c.email = document.getElementById('editCustEmail').value;
  c.phone = document.getElementById('editCustPhone').value;
  c.country = document.getElementById('editCustCountry').value;
  c.address = document.getElementById('editCustAddress').value;
  c.accountNumber = document.getElementById('editCustAcct').value;
  c.balances.USD = parseFloat(document.getElementById('editCustUsd').value) || 0;
  c.balances.EUR = parseFloat(document.getElementById('editCustEur').value) || 0;
  c.balances.GBP = parseFloat(document.getElementById('editCustGbp').value) || 0;
  c.balances.NGN = parseFloat(document.getElementById('editCustNgn').value) || 0;
  c.balances.BTC = parseFloat(document.getElementById('editCustBtc').value) || 0;
  c.balances.ETH = parseFloat(document.getElementById('editCustEth').value) || 0;
  c.balances.USDT = parseFloat(document.getElementById('editCustUsdt').value) || 0;
  c.balances.PILGRIM = parseFloat(document.getElementById('editCustPilgrim').value) || 0;
  c.status = document.getElementById('editCustStatus').value;
  const newPass = document.getElementById('editCustNewPass').value.trim();
  if (newPass) c.password = newPass;
  hideModal('editCustomerModal');
  renderCustomersTable();
  notify('Customer updated successfully', 'success');
}

function creditCustomer(idx) {
  const amount = parseFloat(prompt('Enter credit amount (USD):'));
  if (!isNaN(amount) && amount > 0) {
    DB.customers[idx].balances.USD += amount;
    addTransaction(DB.customers[idx].accountNumber, 'credit', 'Admin Credit', amount, 'USD', 'completed');
    renderCustomersTable();
    notify('Credited ' + formatCurrency(amount, 'USD') + ' to ' + DB.customers[idx].firstName, 'success');
  }
}

function debitCustomer(idx) {
  const amount = parseFloat(prompt('Enter debit amount (USD):'));
  if (!isNaN(amount) && amount > 0) {
    DB.customers[idx].balances.USD = Math.max(0, DB.customers[idx].balances.USD - amount);
    addTransaction(DB.customers[idx].accountNumber, 'debit', 'Admin Debit', amount, 'USD', 'completed');
    renderCustomersTable();
    notify('Debited ' + formatCurrency(amount, 'USD') + ' from ' + DB.customers[idx].firstName, 'warning');
  }
}

function toggleCustStatus(idx) {
  const statuses = ['active', 'suspended', 'frozen'];
  const c = DB.customers[idx];
  const curr = statuses.indexOf(c.status);
  c.status = statuses[(curr + 1) % statuses.length];
  renderCustomersTable();
  notify('Account status changed to: ' + c.status, 'info');
}

function resetCustPassword(idx) {
  const newPass = generatePassword();
  DB.customers[idx].password = newPass;
  notify('New password for ' + DB.customers[idx].firstName + ': ' + newPass, 'info');
}

function changeAdminAccount() {
  const newAcct = document.getElementById('adminAccountNumber').value.trim();
  if (newAcct) {
    DB.admin.accountNumber = newAcct;
    notify('Admin account number changed to: ' + newAcct, 'success');
  }
}

function filterCustomers() {
  const search = document.getElementById('customerSearch').value.toLowerCase();
  const rows = document.querySelectorAll('#customersTableBody tr');
  rows.forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(search) ? '' : 'none';
  });
}

// ============ TRANSACTIONS ============
function addTransaction(account, type, description, amount, currency, status) {
  const tx = {
    id: generateTxId(),
    account, type, description, amount, currency, status,
    date: getDateTime(),
    timestamp: Date.now()
  };
  DB.transactions.push(tx);
  const cust = DB.customers.find(c => c.accountNumber === account);
  if (cust) cust.transactions.push(tx);
  return tx;
}

function populateSenderAccounts() {
  const sel = document.getElementById('senderAccount');
  if (!sel) return;
  sel.innerHTML = '<option value="admin">Admin — ' + DB.admin.accountNumber + '</option>';
  DB.customers.forEach(c => {
    sel.innerHTML += `<option value="${c.accountNumber}">${c.firstName} ${c.lastName} — ${c.accountNumber}</option>`;
  });
}

function toggleSendFields() {
  const type = document.getElementById('sendType').value;
  document.getElementById('receiverBankGroup').style.display = type === 'crypto' ? 'none' : 'block';
  document.getElementById('swiftGroup').style.display = type === 'international' ? 'block' : 'none';
  document.getElementById('ibanGroup').style.display = type === 'international' ? 'block' : 'none';
  document.getElementById('walletGroup').style.display = type === 'crypto' ? 'block' : 'none';
}

function sendPayment() {
  const senderAcct = document.getElementById('senderAccount').value;
  const receiverName = document.getElementById('receiverName').value.trim();
  const receiverBank = document.getElementById('receiverBank').value.trim();
  const receiverAcct = document.getElementById('receiverAccount').value.trim();
  const amount = parseFloat(document.getElementById('sendAmount').value);
  const currency = document.getElementById('sendCurrency').value;
  const desc = document.getElementById('sendDesc').value.trim();
  const mode = document.getElementById('sendMode').value;
  const receiverEmail = document.getElementById('receiverEmail').value.trim();
  const receiverPhone = document.getElementById('receiverPhone').value.trim();

  if (!receiverName || !receiverAcct || isNaN(amount) || amount <= 0) {
    notify('Please fill in all required fields', 'error');
    return;
  }

  // Debit sender
  if (senderAcct === 'admin') {
    if (DB.admin.balance[currency] < amount) { notify('Insufficient balance', 'error'); return; }
    DB.admin.balance[currency] -= amount;
  } else {
    const cust = DB.customers.find(c => c.accountNumber === senderAcct);
    if (cust && cust.balances[currency] < amount) { notify('Insufficient balance', 'error'); return; }
    if (cust) cust.balances[currency] -= amount;
  }

  const tx = addTransaction(senderAcct, 'debit', `Send to ${receiverName} — ${desc} [${mode}]`, amount, currency, 'completed');

  // Ghost delivery notification
  notify('👻 Ghost Delivery: Payment of ' + formatCurrency(amount, currency) + ' sent to ' + receiverName, 'success');
  
  // Simulate notification to receiver
  if (receiverEmail) notify('📧 Email notification sent to ' + receiverEmail, 'info');
  if (receiverPhone) notify('📱 SMS notification sent to ' + receiverPhone, 'info');

  // Credit receiver if they're a GPB customer
  const receiver = DB.customers.find(c => c.accountNumber === receiverAcct);
  if (receiver) {
    receiver.balances[currency] = (receiver.balances[currency] || 0) + amount;
    addTransaction(receiverAcct, 'credit', `Received from ${senderAcct === 'admin' ? 'Admin' : senderAcct} — ${desc}`, amount, currency, 'completed');
    notify('Credit alert sent to ' + receiver.firstName + ' ' + receiver.lastName, 'success');
  }

  renderTxHistory();
  document.getElementById('sendAmount').value = '';
  document.getElementById('receiverName').value = '';
  document.getElementById('receiverAccount').value = '';
}

function internalTransfer() {
  const fromAcct = document.getElementById('transferFrom').value;
  const toAcct = document.getElementById('transferToAcct').value.trim();
  const amount = parseFloat(document.getElementById('transferAmount').value);
  const currency = document.getElementById('transferCurrency').value;
  const narration = document.getElementById('transferNarration').value.trim();

  if (!toAcct || isNaN(amount) || amount <= 0) {
    notify('Please fill required fields', 'error');
    return;
  }

  const receiver = DB.customers.find(c => c.accountNumber === toAcct);
  if (!receiver) { notify('Recipient account not found in GPB', 'error'); return; }

  if (fromAcct === 'admin') {
    if (DB.admin.balance[currency] < amount) { notify('Insufficient balance', 'error'); return; }
    DB.admin.balance[currency] -= amount;
  } else {
    const sender = DB.customers.find(c => c.accountNumber === fromAcct);
    if (sender && sender.balances[currency] < amount) { notify('Insufficient balance', 'error'); return; }
    if (sender) sender.balances[currency] -= amount;
  }

  receiver.balances[currency] = (receiver.balances[currency] || 0) + amount;
  addTransaction(fromAcct, 'debit', `Transfer to ${toAcct} — ${narration}`, amount, currency, 'completed');
  addTransaction(toAcct, 'credit', `Transfer from ${fromAcct} — ${narration}`, amount, currency, 'completed');

  notify('Transfer of ' + formatCurrency(amount, currency) + ' completed!', 'success');
  renderTxHistory();
}

function convertCurrency() {
  const from = document.getElementById('convertFrom').value;
  const to = document.getElementById('convertTo').value;
  const amount = parseFloat(document.getElementById('convertAmount').value);
  if (isNaN(amount) || amount <= 0) { notify('Enter a valid amount', 'error'); return; }

  const rate = getExchangeRate(from, to);
  const result = amount * rate;
  document.getElementById('convertResult').value = formatCurrency(result, to);
  notify('Conversion: ' + formatCurrency(amount, from) + ' = ' + formatCurrency(result, to), 'success');
}

function getExchangeRate(from, to) {
  if (from === to) return 1;
  const key = from + '/' + to;
  if (DB.exchangeRates[key]) return DB.exchangeRates[key];
  // Calculate via USD
  const fromUsd = DB.exchangeRates[from + '/USD'] || (1 / (DB.exchangeRates['USD/' + from] || 1));
  const usdTo = DB.exchangeRates['USD/' + to] || (1 / (DB.exchangeRates[to + '/USD'] || 1));
  return fromUsd * usdTo;
}

function renderTxHistory() {
  const tbody = document.getElementById('txHistoryBody');
  if (!tbody) return;
  const txs = DB.transactions.slice().reverse();
  tbody.innerHTML = txs.slice(0, 50).map(t => `
    <tr>
      <td style="font-family:monospace;font-size:11px">${t.id}</td>
      <td><span class="badge badge-${t.type === 'credit' ? 'success' : 'danger'}">${t.type}</span></td>
      <td style="font-size:12px">${t.account}</td>
      <td>${formatCurrency(t.amount, t.currency)}</td>
      <td>${t.currency}</td>
      <td><span class="badge badge-success">${t.status}</span></td>
      <td style="font-size:11px">${t.date}</td>
    </tr>
  `).join('');
}

// ============ PAYROLL SYSTEM ============
function createDepartment() {
  const title = document.getElementById('newDeptTitle').value.trim();
  if (!title) { notify('Enter department title', 'error'); return; }
  DB.departments.push({ title, people: [], createdAt: new Date().toISOString() });
  hideModal('createDeptModal');
  renderPayroll();
  notify('Department "' + title + '" created', 'success');
}

function renderPayroll() {
  const container = document.getElementById('payrollDepartments');
  if (!container) return;
  if (DB.departments.length === 0) {
    container.innerHTML = '<div style="text-align:center;color:var(--text-muted);padding:30px">No departments created yet</div>';
    return;
  }
  container.innerHTML = DB.departments.map((dept, di) => `
    <div class="dept-card">
      <div class="dept-header">
        <div class="dept-title"><i class="fas fa-building"></i> ${dept.title}</div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-xs btn-success" onclick="payAllInDept(${di})"><i class="fas fa-money-bill-wave"></i> Pay All</button>
          <button class="btn btn-xs btn-primary" onclick="showAddPerson(${di})"><i class="fas fa-user-plus"></i> Add Person</button>
          <button class="btn btn-xs btn-danger" onclick="deleteDept(${di})"><i class="fas fa-trash"></i></button>
        </div>
      </div>
      ${dept.people.length > 0 ? `
      <div style="overflow-x:auto">
        <table class="data-table">
          <thead><tr><th>Name</th><th>Position</th><th>Account</th><th>Bank</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${dept.people.map((p, pi) => `
              <tr>
                <td>${p.name}</td>
                <td>${p.position}</td>
                <td style="font-family:monospace;font-size:11px">${p.account}</td>
                <td>${p.bank}</td>
                <td>${formatCurrency(p.amount, 'NGN')}</td>
                <td><span class="status-dot ${p.paymentStatus === 'success' ? 'green' : p.paymentStatus === 'failed' ? 'red' : 'yellow'}"></span></td>
                <td>
                  <button class="btn btn-xs btn-success" onclick="payPerson(${di},${pi})" title="Send Payment"><i class="fas fa-paper-plane"></i></button>
                  <button class="btn btn-xs btn-info" onclick="editPerson(${di},${pi})" title="Edit"><i class="fas fa-edit"></i></button>
                  <button class="btn btn-xs btn-danger" onclick="deletePerson(${di},${pi})" title="Delete"><i class="fas fa-trash"></i></button>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>` : '<p style="color:var(--text-muted);font-size:13px;padding:12px">No people added yet</p>'}
    </div>
  `).join('');
}

function showAddPerson(deptIdx) {
  document.getElementById('addPersonDeptIdx').value = deptIdx;
  document.getElementById('personName').value = '';
  document.getElementById('personPosition').value = '';
  document.getElementById('personAccount').value = '';
  document.getElementById('personBank').value = '';
  document.getElementById('personAmount').value = '';
  document.getElementById('personPhone').value = '';
  document.getElementById('personEmail').value = '';
  document.getElementById('personAddress').value = '';
  showModal('addPersonModal');
}

function addPersonToDept() {
  const di = parseInt(document.getElementById('addPersonDeptIdx').value);
  const person = {
    name: document.getElementById('personName').value.trim(),
    position: document.getElementById('personPosition').value.trim(),
    account: document.getElementById('personAccount').value.trim(),
    bank: document.getElementById('personBank').value.trim(),
    amount: parseFloat(document.getElementById('personAmount').value) || 0,
    phone: document.getElementById('personPhone').value.trim(),
    email: document.getElementById('personEmail').value.trim(),
    address: document.getElementById('personAddress').value.trim(),
    paymentStatus: 'pending'
  };
  if (!person.name || !person.account) { notify('Name and account number required', 'error'); return; }
  DB.departments[di].people.push(person);
  hideModal('addPersonModal');
  renderPayroll();
  notify(person.name + ' added to ' + DB.departments[di].title, 'success');
}

function payPerson(di, pi) {
  const person = DB.departments[di].people[pi];
  const tx = addTransaction(DB.admin.accountNumber, 'debit', `Payroll: ${person.name} — ${person.position}`, person.amount, 'NGN', 'completed');
  
  // Simulate payment (90% success rate for demo)
  const success = Math.random() > 0.1;
  person.paymentStatus = success ? 'success' : 'failed';
  
  if (success) {
    notify('✅ Payment of ' + formatCurrency(person.amount, 'NGN') + ' sent to ' + person.name + ' at ' + person.bank, 'success');
    if (person.email) notify('📧 Email notification sent to ' + person.email, 'info');
    if (person.phone) notify('📱 SMS notification sent to ' + person.phone, 'info');
  } else {
    notify('❌ Payment to ' + person.name + ' failed — will retry', 'error');
  }
  renderPayroll();
}

function payAllInDept(di) {
  DB.departments[di].people.forEach((p, pi) => payPerson(di, pi));
}

function editPerson(di, pi) {
  const p = DB.departments[di].people[pi];
  const newName = prompt('Name:', p.name);
  if (newName !== null) p.name = newName;
  const newPos = prompt('Position:', p.position);
  if (newPos !== null) p.position = newPos;
  const newAmt = prompt('Amount:', p.amount);
  if (newAmt !== null) p.amount = parseFloat(newAmt) || p.amount;
  const newAcct = prompt('Account Number:', p.account);
  if (newAcct !== null) p.account = newAcct;
  const newBank = prompt('Bank Name:', p.bank);
  if (newBank !== null) p.bank = newBank;
  renderPayroll();
  notify('Person updated', 'success');
}

function deletePerson(di, pi) {
  if (confirm('Delete ' + DB.departments[di].people[pi].name + '?')) {
    DB.departments[di].people.splice(pi, 1);
    renderPayroll();
    notify('Person removed', 'info');
  }
}

function deleteDept(di) {
  if (confirm('Delete department "' + DB.departments[di].title + '" and all its people?')) {
    DB.departments.splice(di, 1);
    renderPayroll();
    notify('Department deleted', 'info');
  }
}

function searchPayroll() {
  const query = document.getElementById('payrollSearch').value.toLowerCase();
  if (!query) { renderPayroll(); return; }
  // Highlight matching results across departments
  DB.departments.forEach(dept => {
    dept.people.forEach(p => {
      p._match = (p.name + p.phone + p.email + p.account).toLowerCase().includes(query);
    });
  });
  renderPayroll();
}

// ============ INVOICES ============
function createInvoice() {
  const to = document.getElementById('invoiceTo').value.trim();
  const email = document.getElementById('invoiceEmail').value.trim();
  const phone = document.getElementById('invoicePhone').value.trim();
  const desc = document.getElementById('invoiceDesc').value.trim();
  const amount = parseFloat(document.getElementById('invoiceAmount').value);
  const currency = document.getElementById('invoiceCurrency').value;
  const dueDate = document.getElementById('invoiceDueDate').value;

  if (!to || !amount) { notify('Name and amount required', 'error'); return; }

  const invoice = {
    id: 'INV-' + Date.now().toString(36).toUpperCase(),
    to, email, phone, desc, amount, currency, dueDate,
    status: 'sent',
    createdAt: getDateTime(),
    txId: generateTxId()
  };

  DB.invoices.push(invoice);
  
  // Notify receiver
  if (email) notify('📧 Invoice sent to ' + email, 'info');
  if (phone) notify('📱 Invoice SMS sent to ' + phone, 'info');
  
  hideModal('createInvoiceModal');
  renderInvoices();
  notify('Invoice ' + invoice.id + ' created and sent!', 'success');
}

function renderInvoices() {
  const tbody = document.getElementById('invoicesTableBody');
  if (!tbody) return;
  if (DB.invoices.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:30px">No invoices yet</td></tr>';
    return;
  }
  tbody.innerHTML = DB.invoices.map((inv, i) => `
    <tr>
      <td style="font-family:monospace;font-size:11px">${inv.id}</td>
      <td>${inv.to}<br><span style="font-size:11px;color:var(--text-muted)">${inv.email || ''}</span></td>
      <td>${formatCurrency(inv.amount, inv.currency)}</td>
      <td><span class="badge badge-${inv.status === 'paid' ? 'success' : inv.status === 'overdue' ? 'danger' : 'warning'}">${inv.status}</span></td>
      <td style="font-size:11px">${inv.createdAt}</td>
      <td>
        <button class="btn btn-xs btn-success" onclick="markInvoicePaid(${i})" title="Mark Paid"><i class="fas fa-check"></i></button>
        <button class="btn btn-xs btn-danger" onclick="deleteInvoice(${i})" title="Delete"><i class="fas fa-trash"></i></button>
      </td>
    </tr>
  `).join('');
}

function markInvoicePaid(i) {
  DB.invoices[i].status = 'paid';
  addTransaction(DB.admin.accountNumber, 'credit', 'Invoice Payment — ' + DB.invoices[i].id, DB.invoices[i].amount, DB.invoices[i].currency, 'completed');
  renderInvoices();
  notify('Invoice marked as paid', 'success');
}

function deleteInvoice(i) {
  DB.invoices.splice(i, 1);
  renderInvoices();
  notify('Invoice deleted', 'info');
}

// ============ RECHARGE CARDS ============
function generateRechargeCard() {
  const network = document.getElementById('rechargeNetwork').value;
  const value = parseInt(document.getElementById('rechargeValue').value);
  const qty = parseInt(document.getElementById('rechargeQty').value) || 1;

  for (let i = 0; i < qty; i++) {
    DB.rechargeCards.push({
      network, value, pin: generateRechargePin(),
      status: 'unused', createdAt: getDateTime()
    });
  }

  renderRechargeCards();
  notify(qty + ' recharge card(s) generated for ' + network, 'success');
}

function renderRechargeCards() {
  const container = document.getElementById('rechargeCardsList');
  if (!container) return;
  if (DB.rechargeCards.length === 0) {
    container.innerHTML = '<p style="color:var(--text-muted);font-size:13px">No recharge cards generated yet</p>';
    return;
  }
  container.innerHTML = DB.rechargeCards.slice(-20).reverse().map((c, i) => `
    <div class="recharge-card" style="margin-bottom:10px">
      <div style="font-size:12px;color:var(--text-muted)">${c.network}</div>
      <div class="card-value">${formatCurrency(c.value, 'NGN')}</div>
      <div class="card-number">${c.pin}</div>
      <span class="badge badge-${c.status === 'unused' ? 'success' : 'info'}">${c.status}</span>
    </div>
  `).join('');
}

// ============ MINING ENGINE ============
function initMining() {
  const allCurrencies = [...CURRENCY_LIST.map(c => c.id), ...CRYPTO_LIST.map(c => c.id)];
  allCurrencies.forEach(cur => {
    DB.mining[cur] = { active: false, mined: 0, hashrate: 0, interval: null };
  });
}

function renderMiningCards() {
  const grid = document.getElementById('miningCardsGrid');
  if (!grid) return;
  
  const items = [
    ...CURRENCY_LIST.map(c => ({ ...c, isCrypto: false })),
    ...CRYPTO_LIST.map(c => ({ ...c, isCrypto: true }))
  ];

  grid.innerHTML = items.map(item => {
    const mining = DB.mining[item.id] || { active: false, mined: 0, hashrate: 0 };
    const isActive = mining.active;
    return `
      <div class="mining-card ${isActive ? 'mining-active' : ''}">
        <div class="coin-icon" style="background:${item.color || 'var(--accent)'}22;color:${item.color || 'var(--accent)'}">
          ${item.icon || item.symbol || item.id[0]}
        </div>
        <div style="font-weight:600;font-size:14px">${item.name || item.id}</div>
        <div style="font-size:11px;color:var(--text-muted)">${item.id}</div>
        <div class="mining-status">
          <div style="font-size:12px;margin-top:8px">Mined: <span style="color:var(--accent)">${mining.mined.toFixed(8)}</span></div>
          <div class="mining-progress"><div class="progress-bar" style="width:${Math.min((mining.mined % 1) * 100, 100)}%"></div></div>
          <div style="font-size:11px;color:var(--text-muted)">Hash: ${mining.hashrate.toFixed(1)} H/s</div>
          ${isActive ? '<span class="badge badge-success">Mining</span>' : '<span class="badge badge-info">Idle</span>'}
        </div>
        <div style="margin-top:10px;display:flex;gap:6px">
          <button class="btn btn-xs ${isActive ? 'btn-danger' : 'btn-success'}" onclick="toggleMining('${item.id}')">
            <i class="fas fa-${isActive ? 'stop' : 'play'}"></i> ${isActive ? 'Stop' : 'Start'}
          </button>
          <button class="btn btn-xs btn-warning" onclick="sendMiningToBalance('${item.id}')">
            <i class="fas fa-arrow-down"></i> Profit
          </button>
        </div>
      </div>
    `;
  }).join('');

  // Update stats
  let activeMiners = 0, totalMined = 0;
  Object.values(DB.mining).forEach(m => { if (m.active) { activeMiners++; totalMined += m.mined; } });
  const am = document.getElementById('activeMiners');
  const tm = document.getElementById('totalMined');
  const mh = document.getElementById('miningHashrate');
  const mp = document.getElementById('miningProfit');
  if (am) am.textContent = activeMiners;
  if (tm) tm.textContent = '$' + totalMined.toFixed(4);
  if (mh) {
    const totalHash = Object.values(DB.mining).reduce((s, m) => s + m.hashrate, 0);
    mh.textContent = totalHash.toFixed(0) + ' H/s';
  }
  if (mp) mp.textContent = totalMined.toFixed(8);
}

function toggleMining(currencyId) {
  const mining = DB.mining[currencyId];
  if (!mining) return;

  if (mining.active) {
    mining.active = false;
    mining.hashrate = 0;
    clearInterval(mining.interval);
    mining.interval = null;
    notify(currencyId + ' mining stopped', 'warning');
  } else {
    mining.active = true;
    mining.hashrate = Math.random() * 500 + 100;
    mining.interval = setInterval(() => {
      const increment = 0.000000001 * (mining.hashrate / 100);
      mining.mined += increment;
      // Update card in real-time
      renderMiningCards();
    }, 3000);
    notify(currencyId + ' mining started!', 'success');
  }
  renderMiningCards();
}

function sendMiningToBalance(currencyId) {
  const mining = DB.mining[currencyId];
  if (!mining || mining.mined <= 0) { notify('No mining profit to send', 'warning'); return; }
  
  const amount = mining.mined;
  DB.admin.balance[currencyId] = (DB.admin.balance[currencyId] || 0) + amount;
  addTransaction(DB.admin.accountNumber, 'credit', `Mining Profit — ${currencyId}`, amount, currencyId, 'completed');
  mining.mined = 0;
  renderMiningCards();
  notify('Mining profit ' + formatCurrency(amount, currencyId) + ' sent to admin balance!', 'success');
}

// ============ TRADING — ROBOT ============
function startRobotTrading() {
  if (DB.tradingState.robotActive) { notify('Robot already running', 'warning'); return; }
  
  const amount = parseFloat(document.getElementById('tradeAmount').value) || 100;
  const leverage = parseInt(document.getElementById('tradeLeverage').value);
  
  if (DB.admin.balance.USD < amount) { notify('Insufficient USD balance', 'error'); return; }
  
  DB.admin.balance.USD -= amount;
  DB.tradingState.robotActive = true;
  DB.tradingState.investment = amount;
  DB.tradingState.leverage = leverage;
  DB.tradingState.profit = 0;
  DB.tradingState.trades = 0;
  DB.tradingState.wins = 0;

  document.getElementById('robotStatus').textContent = 'Online';
  document.getElementById('robotStatus').style.color = 'var(--success)';

  DB.tradingState.interval = setInterval(() => {
    const tradeResult = (Math.random() - 0.4) * amount * leverage * 0.01;
    DB.tradingState.profit += tradeResult;
    DB.tradingState.trades++;
    if (tradeResult > 0) DB.tradingState.wins++;
    
    document.getElementById('tradingProfit').textContent = formatCurrency(DB.tradingState.profit, 'USD');
    document.getElementById('totalTrades').textContent = DB.tradingState.trades;
    document.getElementById('winRate').textContent = ((DB.tradingState.wins / DB.tradingState.trades) * 100).toFixed(0) + '%';
    
    renderTradingChart();
    
    // Trading log
    const log = document.getElementById('tradingLog');
    if (log) {
      log.innerHTML = `<div style="font-size:12px;color:${tradeResult > 0 ? 'var(--success)' : 'var(--danger)'}">
        Trade #${DB.tradingState.trades}: ${tradeResult > 0 ? '+' : ''}${formatCurrency(tradeResult, 'USD')} ${new Date().toLocaleTimeString()}
      </div>` + log.innerHTML;
    }
  }, 2000);

  notify('🤖 Robot trading started!', 'success');
}

function stopRobotTrading() {
  if (!DB.tradingState.robotActive) return;
  DB.tradingState.robotActive = false;
  clearInterval(DB.tradingState.interval);
  document.getElementById('robotStatus').textContent = 'Offline';
  document.getElementById('robotStatus').style.color = 'var(--text)';
  notify('Robot trading stopped', 'warning');
}

function sendProfitToBalance() {
  if (DB.tradingState.profit <= 0) { notify('No profit to send', 'warning'); return; }
  DB.admin.balance.USD += DB.tradingState.profit;
  addTransaction(DB.admin.accountNumber, 'credit', 'Trading Profit — Trade Dragon', DB.tradingState.profit, 'USD', 'completed');
  notify('Trading profit ' + formatCurrency(DB.tradingState.profit, 'USD') + ' sent to admin balance!', 'success');
  DB.tradingState.profit = 0;
  document.getElementById('tradingProfit').textContent = '$0.00';
}

function renderTradingChart() {
  const chart = document.getElementById('tradingChart');
  if (!chart) return;
  chart.innerHTML = '';
  for (let i = 0; i < 30; i++) {
    const height = Math.random() * 80 + 20;
    const isRed = Math.random() > 0.55;
    const bar = document.createElement('div');
    bar.className = 'chart-bar' + (isRed ? ' red' : '');
    bar.style.height = height + '%';
    chart.appendChild(bar);
  }
}

// ============ WALLET MANAGEMENT ============
function renderAdminWallets() {
  const grid = document.getElementById('adminWalletsGrid');
  if (!grid) return;
  grid.innerHTML = CRYPTO_LIST.map(c => {
    const addr = generateWalletAddress(c.id === 'BTC' ? '1' : c.id === 'ETH' ? '0x' : '0x');
    const bal = DB.admin.balance[c.id] || 0;
    return `
      <div class="content-card">
        <div class="card-header">
          <h3 style="color:${c.color}">${c.icon} ${c.name}</h3>
          <span class="badge badge-gold">${c.id}</span>
        </div>
        <div class="card-body">
          <div style="margin-bottom:8px"><strong>Balance:</strong> ${formatCurrency(bal, c.id)}</div>
          <div style="margin-bottom:4px;font-size:12px;color:var(--text-muted)">Wallet Address:</div>
          <div class="wallet-address">${DB.admin.walletAddresses?.[c.id] || addr}</div>
        </div>
      </div>
    `;
  }).join('');
}

// ============ EXCHANGE RATES ============
function renderExchangeRates() {
  const container = document.getElementById('adminExchangeRates');
  if (!container) return;
  const rates = Object.entries(DB.exchangeRates).slice(0, 10);
  container.innerHTML = '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px">' +
    rates.map(([pair, rate]) => {
      const change = (Math.random() - 0.5) * 2;
      return `<div style="background:var(--primary);padding:12px;border-radius:8px;display:flex;justify-content:space-between;align-items:center">
        <span style="font-weight:600;font-size:13px">${pair}</span>
        <span style="font-size:13px;color:${change >= 0 ? 'var(--success)' : 'var(--danger)'}">${rate.toFixed(4)} ${change >= 0 ? '▲' : '▼'}</span>
      </div>`;
    }).join('') + '</div>';
}

function renderDetailedRates() {
  const container = document.getElementById('detailedRates');
  if (!container) return;
  container.innerHTML = '<table class="data-table"><thead><tr><th>Pair</th><th>Rate</th><th>Change</th><th>Updated</th></tr></thead><tbody>' +
    Object.entries(DB.exchangeRates).map(([pair, rate]) => {
      const change = (Math.random() - 0.5) * 3;
      return `<tr>
        <td style="font-weight:600">${pair}</td>
        <td>${rate.toFixed(6)}</td>
        <td style="color:${change >= 0 ? 'var(--success)' : 'var(--danger)'}">${change >= 0 ? '+' : ''}${change.toFixed(3)}%</td>
        <td style="font-size:11px">${getDateTime()}</td>
      </tr>`;
    }).join('') + '</tbody></table>';
}

// ============ LIVE CLOCK & TICKER ============
function updateClocks() {
  const clockStr = getDateTime();
  const ac = document.getElementById('adminClock');
  const cc = document.getElementById('custClock');
  if (ac) ac.textContent = clockStr;
  if (cc) cc.textContent = clockStr;
  setTimeout(updateClocks, 1000);
}

function updateTicker() {
  const pairs = ['BTC/USD', 'ETH/USD', 'EUR/USD', 'GBP/USD', 'USD/NGN', 'XAU/USD'];
  const tickers = [document.getElementById('adminTicker'), document.getElementById('custTicker')];
  
  tickers.forEach(ticker => {
    if (!ticker) return;
    ticker.innerHTML = pairs.map(p => {
      const val = DB.exchangeRates[p.replace('/', '/')] || (Math.random() * 1000);
      const up = Math.random() > 0.5;
      return `<span class="ticker-item">${p} <span class="${up ? 'rate-up' : 'rate-down'}">${up ? '▲' : '▼'}</span></span>`;
    }).join('');
  });

  // Simulate rate fluctuation
  Object.keys(DB.exchangeRates).forEach(key => {
    DB.exchangeRates[key] *= (1 + (Math.random() - 0.5) * 0.002);
  });

  setTimeout(updateTicker, 5000);
}

// ============ CUSTOMER DASHBOARD ============
function initCustomerDashboard() {
  const c = DB.currentCustomer;
  if (!c) return;
  document.getElementById('custDisplayName').textContent = c.firstName + ' ' + c.lastName;
  document.getElementById('custDisplayAcct').textContent = c.accountNumber;
  document.getElementById('custAvatar').textContent = c.firstName[0] + c.lastName[0];
  updateClocks();
  updateTicker();
  refreshCustOverview();
  initCustMining();
}

function refreshCustOverview() {
  const c = DB.currentCustomer;
  if (!c) return;
  document.getElementById('custUsdBal').textContent = formatCurrency(c.balances.USD, 'USD');
  document.getElementById('custEurBal').textContent = formatCurrency(c.balances.EUR, 'EUR');
  document.getElementById('custGbpBal').textContent = formatCurrency(c.balances.GBP, 'GBP');
  document.getElementById('custNgnBal').textContent = formatCurrency(c.balances.NGN, 'NGN');
  document.getElementById('custWelcomeMsg').textContent = 'Welcome, ' + c.firstName + '! Account: ' + c.accountNumber;

  // Recent transactions
  const recentDiv = document.getElementById('custRecentTx');
  if (recentDiv) {
    const recent = c.transactions.slice(-5).reverse();
    if (recent.length) {
      recentDiv.innerHTML = recent.map(t => `
        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(26,58,92,0.5);font-size:12px">
          <div>${t.description}</div>
          <div style="color:${t.type === 'credit' ? 'var(--success)' : 'var(--danger)'}">${t.type === 'credit' ? '+' : '-'}${formatCurrency(t.amount, t.currency)}</div>
        </div>
      `).join('');
    } else {
      recentDiv.innerHTML = '<p style="color:var(--text-muted);font-size:13px">No transactions yet</p>';
    }
  }

  // Crypto balances
  const cryptoDiv = document.getElementById('custCryptoBal');
  if (cryptoDiv) {
    const cryptoBalances = CRYPTO_LIST.filter(crypto => (c.balances[crypto.id] || 0) > 0);
    if (cryptoBalances.length) {
      cryptoDiv.innerHTML = cryptoBalances.map(crypto => `
        <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid rgba(26,58,92,0.5);font-size:12px">
          <span>${crypto.icon} ${crypto.name}</span>
          <span>${formatCurrency(c.balances[crypto.id], crypto.id)}</span>
        </div>
      `).join('');
    } else {
      cryptoDiv.innerHTML = '<p style="color:var(--text-muted);font-size:13px">No crypto balances</p>';
    }
  }
}

// Customer Transactions
function toggleCustSendFields() {
  const type = document.getElementById('custSendType').value;
  document.getElementById('custReceiverBankGroup').style.display = type === 'crypto' ? 'none' : 'block';
  document.getElementById('custSwiftGroup').style.display = type === 'international' ? 'block' : 'none';
  document.getElementById('custIbanGroup').style.display = type === 'international' ? 'block' : 'none';
  document.getElementById('custWalletGroup').style.display = type === 'crypto' ? 'block' : 'none';
}

function custSendPayment() {
  const c = DB.currentCustomer;
  if (!c) return;
  const receiverName = document.getElementById('custReceiverName').value.trim();
  const receiverAcct = document.getElementById('custReceiverAccount').value.trim();
  const amount = parseFloat(document.getElementById('custSendAmount').value);
  const currency = document.getElementById('custSendCurrency').value;
  const desc = document.getElementById('custSendDesc').value.trim();
  const mode = document.getElementById('custSendMode').value;
  const receiverEmail = document.getElementById('custReceiverEmail').value.trim();
  const receiverPhone = document.getElementById('custReceiverPhone').value.trim();

  if (!receiverName || !receiverAcct || isNaN(amount) || amount <= 0) {
    notify('Please fill required fields', 'error'); return;
  }
  if ((c.balances[currency] || 0) < amount) { notify('Insufficient balance', 'error'); return; }

  c.balances[currency] -= amount;
  const tx = addTransaction(c.accountNumber, 'debit', `Send to ${receiverName} — ${desc} [${mode}]`, amount, currency, 'completed');

  // Check if receiver is GPB customer
  const receiver = DB.customers.find(cust => cust.accountNumber === receiverAcct);
  if (receiver) {
    receiver.balances[currency] = (receiver.balances[currency] || 0) + amount;
    addTransaction(receiverAcct, 'credit', `Received from ${c.firstName} ${c.lastName}`, amount, currency, 'completed');
  }

  notify('👻 Payment of ' + formatCurrency(amount, currency) + ' sent to ' + receiverName, 'success');
  if (receiverEmail) notify('📧 Email sent to ' + receiverEmail, 'info');
  if (receiverPhone) notify('📱 SMS sent to ' + receiverPhone, 'info');

  refreshCustOverview();
  custRenderTxHistory();
}

function custConvertCurrency() {
  const c = DB.currentCustomer;
  if (!c) return;
  const from = document.getElementById('custConvertFrom').value;
  const to = document.getElementById('custConvertTo').value;
  const amount = parseFloat(document.getElementById('custConvertAmt').value);
  if (isNaN(amount) || amount <= 0) { notify('Enter valid amount', 'error'); return; }
  if ((c.balances[from] || 0) < amount) { notify('Insufficient ' + from + ' balance', 'error'); return; }

  const rate = getExchangeRate(from, to);
  const result = amount * rate;
  c.balances[from] -= amount;
  c.balances[to] = (c.balances[to] || 0) + result;
  addTransaction(c.accountNumber, 'conversion', `${from} to ${to}`, amount, from, 'completed');

  document.getElementById('custConvertRes').value = formatCurrency(result, to);
  notify('Converted ' + formatCurrency(amount, from) + ' to ' + formatCurrency(result, to), 'success');
  refreshCustOverview();
}

function custRenderTxHistory() {
  const c = DB.currentCustomer;
  if (!c) return;
  const tbody = document.getElementById('custTxHistoryBody');
  if (!tbody) return;
  tbody.innerHTML = c.transactions.slice().reverse().map(t => `
    <tr>
      <td style="font-family:monospace;font-size:11px">${t.id}</td>
      <td><span class="badge badge-${t.type === 'credit' ? 'success' : t.type === 'debit' ? 'danger' : 'info'}">${t.type}</span></td>
      <td style="font-size:12px">${t.description}</td>
      <td>${formatCurrency(t.amount, t.currency)}</td>
      <td><span class="badge badge-success">${t.status}</span></td>
      <td style="font-size:11px">${t.date}</td>
    </tr>
  `).join('');
}

function populateCustReceiveDetails() {
  const c = DB.currentCustomer;
  if (!c) return;
  const acctField = document.getElementById('custReceiveAcct');
  const nameField = document.getElementById('custReceiveName');
  if (acctField) acctField.value = c.accountNumber;
  if (nameField) nameField.value = c.firstName + ' ' + c.lastName;
}

// Customer Mining
function initCustMining() {
  const c = DB.currentCustomer;
  if (!c) return;
  if (!c.mining) {
    c.mining = {};
    [...CURRENCY_LIST.map(cu => cu.id), ...CRYPTO_LIST.map(cu => cu.id)].forEach(cur => {
      c.mining[cur] = { active: false, mined: 0, hashrate: 0, interval: null };
    });
  }
}

function renderCustMiningCards() {
  const c = DB.currentCustomer;
  if (!c || !c.mining) return;
  const grid = document.getElementById('custMiningGrid');
  if (!grid) return;

  const items = [
    ...CURRENCY_LIST.slice(0, 4).map(cu => ({ ...cu, isCrypto: false })),
    ...CRYPTO_LIST.slice(0, 8).map(cu => ({ ...cu, isCrypto: true }))
  ];

  let activeCount = 0, totalMined = 0;
  Object.values(c.mining).forEach(m => { if (m.active) { activeCount++; totalMined += m.mined; } });

  document.getElementById('custMiningCount').textContent = activeCount;
  document.getElementById('custMinedTotal').textContent = totalMined.toFixed(8);

  grid.innerHTML = items.map(item => {
    const mining = c.mining[item.id] || { active: false, mined: 0, hashrate: 0 };
    return `
      <div class="mining-card ${mining.active ? 'mining-active' : ''}">
        <div class="coin-icon" style="background:${item.color || 'var(--accent)'}22;color:${item.color || 'var(--accent)'}">
          ${item.icon || item.symbol || item.id[0]}
        </div>
        <div style="font-weight:600;font-size:14px">${item.name || item.id}</div>
        <div style="font-size:12px;margin-top:6px">Mined: <span style="color:var(--accent)">${mining.mined.toFixed(8)}</span></div>
        <div class="mining-progress"><div class="progress-bar" style="width:${Math.min((mining.mined % 1) * 100, 100)}%"></div></div>
        <div style="margin-top:8px;display:flex;gap:6px">
          <button class="btn btn-xs ${mining.active ? 'btn-danger' : 'btn-success'}" onclick="custToggleMining('${item.id}')">
            <i class="fas fa-${mining.active ? 'stop' : 'play'}"></i> ${mining.active ? 'Stop' : 'Start'}
          </button>
        </div>
      </div>
    `;
  }).join('');
}

function custToggleMining(currencyId) {
  const c = DB.currentCustomer;
  if (!c || !c.mining) return;
  const mining = c.mining[currencyId];
  if (!mining) return;

  if (mining.active) {
    mining.active = false;
    mining.hashrate = 0;
    clearInterval(mining.interval);
    mining.interval = null;
  } else {
    mining.active = true;
    mining.hashrate = Math.random() * 200 + 50;
    mining.interval = setInterval(() => {
      mining.mined += 0.000000001 * (mining.hashrate / 100);
      renderCustMiningCards();
    }, 5000);
  }
  renderCustMiningCards();
}

function custSendMiningProfit() {
  const c = DB.currentCustomer;
  if (!c || !c.mining) return;
  let totalSent = 0;
  Object.entries(c.mining).forEach(([cur, mining]) => {
    if (mining.mined > 0) {
      c.balances[cur] = (c.balances[cur] || 0) + mining.mined;
      addTransaction(c.accountNumber, 'credit', `Mining Profit — ${cur}`, mining.mined, cur, 'completed');
      totalSent += mining.mined;
      mining.mined = 0;
    }
  });
  if (totalSent > 0) {
    notify('All mining profits sent to balance!', 'success');
  } else {
    notify('No mining profit to send', 'warning');
  }
  renderCustMiningCards();
  refreshCustOverview();
}

// Customer Trading
function custStartRobot() {
  const c = DB.currentCustomer;
  if (!c) return;
  if (DB.custTradingState.robotActive) { notify('Robot already running', 'warning'); return; }
  const amount = parseFloat(document.getElementById('custTradeAmt').value) || 50;
  const leverage = parseInt(document.getElementById('custTradeLev').value);
  if (c.balances.USD < amount) { notify('Insufficient USD balance', 'error'); return; }

  c.balances.USD -= amount;
  DB.custTradingState.robotActive = true;
  DB.custTradingState.profit = 0;
  DB.custTradingState.investment = amount;
  document.getElementById('custRobotStatus').textContent = 'Online';
  document.getElementById('custRobotStatus').style.color = 'var(--success)';

  DB.custTradingState.interval = setInterval(() => {
    const result = (Math.random() - 0.4) * amount * leverage * 0.01;
    DB.custTradingState.profit += result;
    document.getElementById('custTradeProfit').textContent = formatCurrency(DB.custTradingState.profit, 'USD');
    renderCustTradingChart();
  }, 2500);

  notify('🤖 Robot trading started!', 'success');
}

function custStopRobot() {
  if (!DB.custTradingState.robotActive) return;
  DB.custTradingState.robotActive = false;
  clearInterval(DB.custTradingState.interval);
  document.getElementById('custRobotStatus').textContent = 'Offline';
  document.getElementById('custRobotStatus').style.color = 'var(--text)';
  notify('Robot stopped', 'warning');
}

function custSendTradeProfit() {
  const c = DB.currentCustomer;
  if (!c) return;
  if (DB.custTradingState.profit <= 0) { notify('No profit to send', 'warning'); return; }
  c.balances.USD += DB.custTradingState.profit;
  addTransaction(c.accountNumber, 'credit', 'Trading Profit — Trade Dragon', DB.custTradingState.profit, 'USD', 'completed');
  notify('Trading profit ' + formatCurrency(DB.custTradingState.profit, 'USD') + ' sent to balance!', 'success');
  DB.custTradingState.profit = 0;
  document.getElementById('custTradeProfit').textContent = '$0.00';
  refreshCustOverview();
}

function renderCustTradingChart() {
  const chart = document.getElementById('custTradingChart');
  if (!chart) return;
  chart.innerHTML = '';
  for (let i = 0; i < 25; i++) {
    const height = Math.random() * 80 + 20;
    const isRed = Math.random() > 0.5;
    const bar = document.createElement('div');
    bar.className = 'chart-bar' + (isRed ? ' red' : '');
    bar.style.height = height + '%';
    chart.appendChild(bar);
  }
}

// Customer Wallets
function renderCustWallets() {
  const c = DB.currentCustomer;
  if (!c) return;
  const grid = document.getElementById('custWalletsGrid');
  if (!grid) return;
  grid.innerHTML = CRYPTO_LIST.map(crypto => {
    const bal = c.balances[crypto.id] || 0;
    const addr = c.walletAddresses[crypto.id] || generateWalletAddress('0x');
    return `
      <div class="content-card">
        <div class="card-header">
          <h3 style="color:${crypto.color}">${crypto.icon} ${crypto.name}</h3>
          <span class="badge badge-gold">${crypto.id}</span>
        </div>
        <div class="card-body">
          <div style="margin-bottom:8px"><strong>Balance:</strong> ${formatCurrency(bal, crypto.id)}</div>
          <div style="margin-bottom:4px;font-size:12px;color:var(--text-muted)">Wallet Address:</div>
          <div class="wallet-address">${addr}</div>
        </div>
      </div>
    `;
  }).join('');
}

// Customer Recharge
function custBuyRecharge() {
  const c = DB.currentCustomer;
  if (!c) return;
  const network = document.getElementById('custRechNetwork').value;
  const value = parseInt(document.getElementById('custRechValue').value);
  const phone = document.getElementById('custRechPhone').value.trim();

  const ngnCost = value * 1.05;
  const usdCost = ngnCost / (DB.exchangeRates['USD/NGN'] || 1580);

  if (c.balances.USD < usdCost) { notify('Insufficient USD balance', 'error'); return; }

  c.balances.USD -= usdCost;
  const pin = generateRechargePin();
  addTransaction(c.accountNumber, 'debit', `Recharge Card — ${network} ₦${value}`, usdCost, 'USD', 'completed');

  const card = { network, value, pin, phone, createdAt: getDateTime() };
  if (!c.rechargeCards) c.rechargeCards = [];
  c.rechargeCards.push(card);

  notify('Recharge card purchased! PIN: ' + pin, 'success');
  if (phone) notify('📱 Recharge PIN sent to ' + phone, 'info');
  
  renderCustRechargeCards();
  refreshCustOverview();
}

function renderCustRechargeCards() {
  const c = DB.currentCustomer;
  if (!c) return;
  const container = document.getElementById('custRechargeList');
  if (!container) return;
  const cards = c.rechargeCards || [];
  if (cards.length === 0) {
    container.innerHTML = '<p style="color:var(--text-muted);font-size:13px">No recharge cards purchased</p>';
    return;
  }
  container.innerHTML = cards.slice(-10).reverse().map(card => `
    <div class="recharge-card" style="margin-bottom:10px">
      <div style="font-size:12px;color:var(--text-muted)">${card.network}</div>
      <div class="card-value">${formatCurrency(card.value, 'NGN')}</div>
      <div class="card-number">${card.pin}</div>
    </div>
  `).join('');
}

// Customer Profile
function custUpdateProfile() {
  const c = DB.currentCustomer;
  if (!c) return;
  c.firstName = document.getElementById('custProfName').value.split(' ')[0] || c.firstName;
  c.lastName = document.getElementById('custProfName').value.split(' ').slice(1).join(' ') || c.lastName;
  c.email = document.getElementById('custProfEmail').value || c.email;
  c.phone = document.getElementById('custProfPhone').value || c.phone;
  c.address = document.getElementById('custProfAddr').value || c.address;
  c.country = document.getElementById('custProfCountry').value || c.country;
  notify('Profile updated successfully', 'success');
  refreshCustOverview();
}

function custChangePassword() {
  const c = DB.currentCustomer;
  if (!c) return;
  const curr = document.getElementById('custCurrPass').value;
  const newP = document.getElementById('custNewPass').value;
  const conf = document.getElementById('custConfPass').value;
  if (curr !== c.password) { notify('Current password incorrect', 'error'); return; }
  if (newP !== conf) { notify('Passwords do not match', 'error'); return; }
  if (newP.length < 6) { notify('Password too short', 'error'); return; }
  c.password = newP;
  notify('Password changed successfully!', 'success');
  document.getElementById('custCurrPass').value = '';
  document.getElementById('custNewPass').value = '';
  document.getElementById('custConfPass').value = '';
}

function custGeneratePassword() {
  const newPass = generatePassword(16);
  document.getElementById('custNewPass').value = newPass;
  document.getElementById('custConfPass').value = newPass;
  notify('Secure password generated: ' + newPass, 'info');
}

// ============ PAYMENT PROCESSING ============
function processPayment() {
  const method = document.getElementById('payMethod').value;
  const amount = parseFloat(document.getElementById('payAmount').value);
  const currency = document.getElementById('payCurrency').value;
  const desc = document.getElementById('payDesc').value;
  if (isNaN(amount) || amount <= 0) { notify('Enter valid amount', 'error'); return; }
  
  addTransaction(DB.admin.accountNumber, 'credit', `Payment — ${method}: ${desc}`, amount, currency, 'completed');
  hideModal('paymentModal');
  notify('Payment of ' + formatCurrency(amount, currency) + ' via ' + method + ' processed!', 'success');
}

// ============ INITIALIZE APP ============
function init() {
  initMining();
  // Generate admin wallet addresses
  DB.admin.walletAddresses = {};
  CRYPTO_LIST.forEach(c => {
    const prefixes = { BTC: '1', ETH: '0x', USDT: 'T', BNB: 'bnb1', SOL: 'So1', PILGRIM: 'P' };
    DB.admin.walletAddresses[c.id] = generateWalletAddress(prefixes[c.id] || '0x');
  });
  
  // Start clock
  updateClocks();
  
  // Show admin login page by default
  showPage('adminLoginPage');
}

// Run on load
document.addEventListener('DOMContentLoaded', init);
